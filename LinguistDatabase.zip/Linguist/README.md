A Basic REST api for the local linguistics app.
NOTE sendfiles is still unfinished, as it needs to include the ability to upload multiple audio files and rename them