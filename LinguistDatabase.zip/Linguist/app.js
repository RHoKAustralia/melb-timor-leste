/*jshint node:true*/

//------------------------------------------------------------------------------
// Local linguist app
//------------------------------------------------------------------------------

// This application uses express as it's web server
// for more info, see: http://expressjs.com
var express = require('express');

var bodyParser = require('body-parser');

var querystring = require('querystring');

// cfenv provides access to your Cloud Foundry environment
// for more info, see: https://www.npmjs.com/package/cfenv
var cfenv = require('cfenv');


// create a new express server
var app = express();


app.use(bodyParser.json());

// parse application/json
var multer = require('multer');
var multerAudio = multer(
	{ 
		dest: './uploads/audio/'

	}
);

var DB_CONFIG = {
	host     : 'us-cdbr-iron-east-02.cleardb.net',
	user     : 'b0278c5fa65573',
	password : 'bc9dd300',
	database : 'ad_68851f308f66b09',
	connectTimeout : '3600*1000'
}
var mysql      = require('mysql');
var connection;


handleDisconnect();

// serve the files out of ./public as our main files
//app.use(express.static(__dirname + '/public'));


//sends phone data
//TODO ALLOW RENAMING OF AUDIO NAMES AND LINK TO DB
//TODO ALLOW FOR NOT UPLOADING AUDIO
app.post('/api/send-phone-data', multerAudio, function (req,res){

	//parse data as JSON
	var data = JSON.parse(querystring.parse("data="+req.body.data).data);
	if(typeof data !== 'undefined' && data !== {}){
		//test data
		var phoneInstallQuery="INSERT IGNORE INTO phoneinstall (GUID) VALUES ('"+data.guid+"')";	
		


		//phone install query
		connection.query(phoneInstallQuery, function(err, rows, fields) {
			if (err) throw err;
		  	console.log("phone install rows", rows);
		  	for(var i=0;i<data.people.length;i++){

		  		(function(personNum){
			  		var personQuery = "INSERT INTO person (GUID, Name, Age, Location, Gender) VALUES ('"+data.guid+"','"+data.people[personNum].name+"','"+data.people[personNum].age+"','"+data.people[personNum].location+"','"+data.people[personNum].gender+"')";
			  		//person query
				 	connection.query(personQuery, function(err, rows, fields) {
						if (err) throw err;
					  	console.log("person rows", rows);

					  	for(var j=0;j<data.people[personNum].words.length;j++){
					  		//person word query
							var personWordQuery = "INSERT INTO personword (PersonID, WordID, AudioFilename, WordEntered) VALUES ('"+rows.insertId+"','"+data.people[personNum].words[j].wordId+"','"+data.people[personNum].words[j].audioFilename+"','"+data.people[personNum].words[j].wordEntered+"')"; 	
							connection.query(personWordQuery, function(err, rows, fields) {
								if (err) throw err;
								console.log("person word rows", rows);
							});
					  	}


						for(var j=0;j<data.people[personNum].languages.length;j++){
							//person language query
							var personLanguageQuery = "INSERT INTO personlanguage (PersonID, LanguageID) VALUES ('"+rows.insertId+"','"+data.people[personNum].languages[j]+"')";
							connection.query(personLanguageQuery, function(err, rows, fields) {
								if (err) throw err;
								console.log("person language rows", rows);
							});	
						}
						
					});
		  		})(i);

			}
		});
	}
	res.json({"STATUS": "SUCCESS"});
});


//gets studies
app.get('/api/get-studies', function (req,res){
	//get studies query
	var getStudyQuery = "SELECT * FROM study";
	connection.query(getStudyQuery, function(err, rows, fields) {
		if (err) throw err;
		res.json(rows)
	});	

})

//gets study words
app.get('/api/get-study-words', function (req,res){
	console.log(req);
	var studyId = (parseInt(req.query.studyId) == req.query.studyId ) ? req.query.studyId : 0;
	//get studies query
	var getStudyQuery = "SELECT * FROM word WHERE WordID IN (SELECT WordID FROM studyword WHERE StudyID = "+studyId+")";
	console.log(getStudyQuery);
	connection.query(getStudyQuery, function(err, rows, fields) {
		if (err) throw err;
		res.json(rows)
	});	

})

//gets all words
app.get('/api/get-words', function (req,res){
	console.log(req);
	var studyId = (parseInt(req.query.studyId) == req.query.studyId ) ? req.query.studyId : 0;
	//get studies query
	var getStudyQuery = "SELECT * FROM word";
	console.log(getStudyQuery);
	connection.query(getStudyQuery, function(err, rows, fields) {
		if (err) throw err;
		res.json(rows)
	});	

})


function handleDisconnect() {

  	connection = mysql.createConnection(DB_CONFIG); // Recreate the connection, since
                                                  // the old one cannot be reused.

  	connection.connect(function(err) {              // The server is either down
    	if(err) {                                     // or restarting (takes a while sometimes).
      		console.log('error when connecting to db:', err);
      		setTimeout(handleDisconnect, 2000); // We introduce a delay before attempting to reconnect,
    	}                                     // to avoid a hot loop, and to allow our node script to
  	});                                     // process asynchronous requests in the meantime.
                                          // If you're also serving http, display a 503 error.
  	connection.on('error', function(err) {
    	if(err.code === 'PROTOCOL_CONNECTION_LOST') { // Connection to the MySQL server is usually
      		handleDisconnect();                         // lost due to either server restart, or a
    	} else {                                      // connnection idle timeout (the wait_timeout
      		throw err;                                  // server variable configures this)
    	}
  	});
}


// get the app environment from Cloud Foundry
var appEnv = cfenv.getAppEnv();

// start server on the specified port and binding host
app.listen(appEnv.port, appEnv.bind, function() {

	// print a message when the server starts listening
  console.log("server starting on " + appEnv.url);
});
